# 🔄 System Architecture - How Everything Connects

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER'S BROWSER                          │
│                      http://localhost:3000                      │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │                   React Frontend (App.jsx)                │ │
│  │                                                           │ │
│  │  • Blue & Yellow colorful UI                             │ │
│  │  • Upload zone for proof images                          │ │
│  │  • Progress bar showing status                           │ │
│  │  • Results display with grades & errors                  │ │
│  └───────────────────────────────────────────────────────────┘ │
│                              │                                  │
│                              │ HTTP Requests                    │
│                              ▼                                  │
└─────────────────────────────────────────────────────────────────┘
                                │
                                │
                                │
┌───────────────────────────────┼─────────────────────────────────┐
│                               │                                 │
│                  BACKEND SERVER (Flask)                         │
│                  http://localhost:5000                          │
│                                                                 │
│  ┌────────────────────────────────────────────────────────────┐│
│  │                      app.py (Flask API)                    ││
│  │                                                            ││
│  │  Endpoints:                                                ││
│  │  • POST /api/grade          → Upload image                ││
│  │  • GET  /api/grade/:id      → Check status                ││
│  │  • GET  /api/results/:id    → Get results                 ││
│  │  • GET  /outputs/:filename  → Serve images                ││
│  └────────────────────────────────────────────────────────────┘│
│                              │                                  │
│                              │ Calls                            │
│                              ▼                                  │
│  ┌────────────────────────────────────────────────────────────┐│
│  │               find_text_lines.py (OpenCV)                  ││
│  │                                                            ││
│  │  • Detects text lines in image                            ││
│  │  • Draws green boxes around lines                         ││
│  │  • Numbers each line in red                               ││
│  │  • Returns: boxed image + layout data                     ││
│  └────────────────────────────────────────────────────────────┘│
│                              │                                  │
│                              │ Then calls                       │
│                              ▼                                  │
│  ┌────────────────────────────────────────────────────────────┐│
│  │          grade_proof.py (Claude AI Integration)            ││
│  │                                                            ││
│  │  • Sends boxed image to Claude API                        ││
│  │  • Gets grading response (grade + errors)                 ││
│  │  • Annotates image with error bubbles                     ││
│  │  • Returns: final grade + annotated image                 ││
│  └────────────────────────────────────────────────────────────┘│
│                              │                                  │
│                              │ Uses                             │
│                              ▼                                  │
│  ┌────────────────────────────────────────────────────────────┐│
│  │                     Anthropic Claude API                   ││
│  │                  (claude-3-5-sonnet-20240620)              ││
│  │                                                            ││
│  │  • Analyzes the mathematical proof                        ││
│  │  • Identifies errors by line number                       ││
│  │  • Assigns overall grade                                  ││
│  └────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

## 📊 Data Flow

### 1️⃣ User Uploads Image
```
User → [React] → POST /api/grade → [Flask]
                                      ↓
                                  Save to uploads/
                                      ↓
                                  Generate job_id
                                      ↓
                                  Start background thread
                                      ↓
                            Return job_id to frontend
```

### 2️⃣ Frontend Polls for Status
```
[React] → GET /api/grade/:job_id → [Flask]
            ↑                         ↓
            └─── Every 1 second ──────┘
            
Response: { status, progress, message }
```

### 3️⃣ Backend Processes Image
```
[Background Thread]
    ↓
find_text_lines.py
    • Load image with OpenCV
    • Detect text lines
    • Draw boxes and numbers
    • Return boxed_image + layout_data
    ↓
grade_proof.py
    • Encode image to base64
    • Send to Claude API
    • Receive grading JSON
    • Annotate image with errors
    • Save annotated image
    ↓
Update job status to "done"
```

### 4️⃣ Frontend Gets Results
```
[React] detects status = "done"
    ↓
GET /api/results/:job_id → [Flask]
    ↓
Returns:
{
  total_grade: "B+",
  sections: [errors...],
  pdfAnnotatedUrl: "/outputs/image.jpg"
}
    ↓
[React] displays results
    ↓
GET /outputs/image.jpg → [Flask] → Return annotated image
```

## 🎨 UI Flow

```
┌─────────────────────┐
│   Upload Screen     │
│                     │
│  [Blue Upload Box]  │
│   Drop image here   │
│  [Choose File Btn]  │
└──────────┬──────────┘
           │ User uploads
           ▼
┌─────────────────────┐
│  Processing Screen  │
│                     │
│  [Spinning Loader]  │
│   [Progress Bar]    │
│   "Grading proof"   │
└──────────┬──────────┘
           │ Processing complete
           ▼
┌─────────────────────┐
│   Results Screen    │
│                     │
│  [Blue Card: B+]    │
│  [Yellow: Image]    │
│  [Red: Errors]      │
│  [Grade Another]    │
└─────────────────────┘
```

## 🔐 Environment Variables

```
.env file (in backend folder):
├── ANTHROPIC_API_KEY=sk-ant-xxxxx     # Your Claude API key
└── ANTHROPIC_MODEL_NAME=claude-3-5... # Model to use
```

## 📁 File Storage

```
backend/
├── uploads/              # Temporary uploaded images
│   └── {job_id}_proof.jpg
│
└── outputs/              # Final annotated images
    └── {job_id}_annotated.jpg
```

## 🔄 Job Status States

```
"processing" → Working on it
    ├─ progress: 10  → "Uploading..."
    ├─ progress: 40  → "Detecting text lines..."
    ├─ progress: 70  → "Grading proof..."
    └─ progress: 100 → "Complete!"

"done"      → Ready to get results
"failed"    → Something went wrong
```

## 🌐 Port Configuration

```
Frontend:  http://localhost:3000  (React dev server)
Backend:   http://localhost:5000  (Flask server)

Change in App.jsx if needed:
const API_BASE_URL = 'http://localhost:5000';
```

## 🚀 Quick Start Commands

```bash
# Terminal 1 - Backend
cd backend
pip install -r requirements.txt
python app.py

# Terminal 2 - Frontend  
cd frontend
npm install framer-motion
npm start

# Terminal 3 - Test (optional)
cd backend
python test_backend.py
```

## ✅ Health Check Sequence

```
1. Backend running?     → curl http://localhost:5000/api/test
2. Frontend running?    → Open http://localhost:3000
3. Can upload?          → Drag & drop image
4. See progress?        → Progress bar moves
5. See results?         → Grade and errors display
6. See annotated image? → Yellow-bordered image shows
```

## 🎯 Complete Request/Response Examples

### Upload Request
```javascript
POST http://localhost:5000/api/grade
Content-Type: multipart/form-data

Body: file=proof.jpg
```

### Upload Response
```json
{
  "jobId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### Status Request
```javascript
GET http://localhost:5000/api/grade/550e8400-e29b-41d4-a716-446655440000
```

### Status Response (Processing)
```json
{
  "status": "processing",
  "progress": 40,
  "message": "Detecting text lines..."
}
```

### Status Response (Done)
```json
{
  "status": "done",
  "progress": 100,
  "message": "Complete!"
}
```

### Results Request
```javascript
GET http://localhost:5000/api/results/550e8400-e29b-41d4-a716-446655440000
```

### Results Response
```json
{
  "total_grade": "B+",
  "sections": [
    {
      "number": 3,
      "error": "Missing justification for this step"
    },
    {
      "number": 7,
      "error": "Algebraic error in simplification"
    }
  ],
  "pdfAnnotatedUrl": "/outputs/550e8400_annotated.jpg"
}
```

---

**🎉 This diagram shows how all the pieces fit together!**
