# 📐 AI-Powered Mathematical Proof Grader

An intelligent web application that uses Claude AI to automatically grade mathematical proofs, providing detailed feedback and annotations.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.8+-blue.svg)
![React](https://img.shields.io/badge/react-18+-blue.svg)

## ✨ Features

- 🤖 **AI-Powered Grading** - Uses Anthropic's Claude to analyze mathematical proofs
- 🎨 **Beautiful UI** - Modern React interface with blue and yellow color scheme
- 📊 **Real-time Progress** - Live updates as your proof is being graded
- 🖼️ **Visual Annotations** - Error bubbles and arrows directly on your proof image
- 📝 **Detailed Feedback** - Line-by-line error identification and descriptions
- 🚀 **Fast Processing** - Automated text detection and grading pipeline

## 🎥 Demo

*Upload a proof image, watch it get graded, and receive detailed feedback with visual annotations!*

## 🏗️ Architecture

```
Frontend (React) ←→ Backend (Flask) ←→ Claude AI API
                         ↓
                    OpenCV Processing
```

- **Frontend**: React with Framer Motion animations
- **Backend**: Flask REST API with background job processing
- **AI**: Anthropic Claude 3.5 Sonnet for grading
- **Vision**: OpenCV for text line detection and annotation

## 📋 Prerequisites

- Python 3.8 or higher
- Node.js 16 or higher
- Anthropic API key ([Get one here](https://console.anthropic.com/))

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/proof-grader.git
cd proof-grader
```

### 2. Backend Setup

```bash
cd backend

# Install Python dependencies
pip install -r requirements.txt

# Create environment file
cp .env.example .env

# Edit .env and add your Anthropic API key
nano .env  # or use your preferred editor
```

### 3. Frontend Setup

```bash
cd frontend

# Install Node dependencies
npm install

# Start development server
npm start
```

### 4. Start the Backend

```bash
cd backend
python app.py
```

### 5. Open in Browser

Navigate to `http://localhost:3000` and start grading proofs!

## 📖 Detailed Setup

For detailed setup instructions, see [SETUP_INSTRUCTIONS.md](SETUP_INSTRUCTIONS.md)

For architecture details, see [ARCHITECTURE.md](ARCHITECTURE.md)

## 🧪 Testing

Test the backend API:

```bash
cd backend
python test_backend.py
```

## 📁 Project Structure

```
proof-grader/
├── backend/
│   ├── app.py                 # Flask API server
│   ├── grade_proof.py         # AI grading logic
│   ├── find_text_lines.py     # Text detection with OpenCV
│   ├── requirements.txt       # Python dependencies
│   ├── .env.example           # Environment template
│   └── test_backend.py        # Test suite
├── frontend/
│   ├── src/
│   │   └── App.jsx            # React application
│   ├── package.json
│   └── ...
├── .gitignore
├── README.md
└── LICENSE
```

## 🔑 Environment Variables

Create a `.env` file in the `backend/` directory:

```bash
ANTHROPIC_API_KEY=your_anthropic_api_key_here
ANTHROPIC_MODEL_NAME=claude-3-5-sonnet-20240620
```

**⚠️ Never commit your .env file to version control!**

## 🛠️ API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/test` | Health check |
| POST | `/api/grade` | Upload proof image |
| GET | `/api/grade/:jobId` | Check processing status |
| GET | `/api/results/:jobId` | Get grading results |
| GET | `/outputs/:filename` | Retrieve annotated images |

## 🎨 Tech Stack

### Backend
- **Flask** - Web framework
- **Anthropic Claude** - AI for grading
- **OpenCV** - Image processing
- **Pillow** - Image manipulation
- **NumPy** - Numerical operations

### Frontend
- **React** - UI framework
- **Framer Motion** - Animations
- **Fetch API** - HTTP requests

## 📝 Usage

1. **Upload a Proof**: Drag and drop or click to upload an image of a mathematical proof
2. **Processing**: The system detects text lines, sends to Claude AI, and generates annotations
3. **Review Results**: See your grade (A-F) and detailed error descriptions
4. **Download**: Get the annotated image with error markers

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Anthropic for the Claude API
- OpenCV community for computer vision tools
- React and Flask communities

## 📧 Contact

Your Name - [@yourtwitter](https://twitter.com/yourtwitter)

Project Link: [https://github.com/yourusername/proof-grader](https://github.com/yourusername/proof-grader)

## ⚠️ Disclaimer

This is an educational tool. Always review AI-generated feedback critically.

---

**Made with ❤️ using React, Flask, OpenCV, and Claude AI**
