# 🚀 Complete Setup Instructions

## Overview
This connects your React frontend to the Python backend that grades mathematical proofs using Claude AI.

## Project Structure
```
proof-grading-system/
├── backend/
│   ├── app.py                 # Flask API server (NEW)
│   ├── grade_proof.py         # Your grading logic
│   ├── find_text_lines.py     # Your text detection
│   ├── __init__.py
│   ├── requirements.txt       # Python dependencies (NEW)
│   ├── .env                   # API keys
│   ├── uploads/               # Uploaded images (created automatically)
│   └── outputs/               # Annotated results (created automatically)
└── frontend/
    ├── src/
    │   └── App.jsx            # React frontend (NEW - colorful version)
    ├── package.json
    └── ...
```

---

## 🔧 Backend Setup (Python/Flask)

### Step 1: Install Python Dependencies

```bash
cd backend

# Install required packages
pip install -r requirements.txt

# Or install individually:
pip install Flask flask-cors anthropic python-dotenv Pillow opencv-python numpy
```

### Step 2: Create .env File

Create a `.env` file in the `backend/` folder:

```bash
ANTHROPIC_API_KEY=your_anthropic_api_key_here
ANTHROPIC_MODEL_NAME=claude-3-5-sonnet-20240620
```

**Get your API key from:** https://console.anthropic.com/

### Step 3: Add Font File (Optional but Recommended)

For better annotations, download a font file:

```bash
# On Ubuntu/Debian:
sudo apt-get install fonts-dejavu-core

# On Mac:
# DejaVuSans.ttf is usually already available

# On Windows:
# Download from: https://dejavu-fonts.github.io/
# Place DejaVuSans.ttf in the backend folder
```

### Step 4: Start the Backend Server

```bash
cd backend
python app.py
```

You should see:
```
==================================================
🚀 Proof Grading Backend Server Starting...
==================================================

📋 Available Endpoints:
  GET  /api/test              - Test connection
  POST /api/grade             - Upload proof image
  GET  /api/grade/<job_id>    - Check processing status
  GET  /api/results/<job_id>  - Get grading results
  GET  /outputs/<filename>    - Get annotated images

==================================================
✅ Server running on http://localhost:5000
==================================================
```

### Step 5: Test Backend Connection

Open a new terminal and test:

```bash
curl http://localhost:5000/api/test
```

You should get:
```json
{"message": "Backend connected!", "status": "ok"}
```

---

## 🎨 Frontend Setup (React)

### Step 1: Install Node Dependencies

```bash
cd frontend

# Install dependencies
npm install framer-motion
```

### Step 2: Add the App.jsx File

Replace your existing `src/App.jsx` with the new colorful version provided.

### Step 3: Update API URL (if needed)

In `App.jsx`, check line 5:

```javascript
const API_BASE_URL = 'http://localhost:5000';
```

If your backend runs on a different port, change this URL.

### Step 4: Start the Frontend

```bash
npm start
```

The React app should open at `http://localhost:3000`

---

## 🧪 Testing the Full System

### Test 1: Frontend Connects to Backend

1. Open your browser to `http://localhost:3000`
2. Open browser console (F12)
3. You should see the blue and yellow colorful interface
4. No CORS errors in console

### Test 2: Upload and Grade a Proof

1. Prepare a test image of a mathematical proof
2. Drag and drop it into the upload zone (or click "Choose File")
3. Watch the progress:
   - "Uploading your proof..." (10%)
   - "Detecting text lines..." (40%)
   - "Grading proof..." (70%)
   - "Creating annotated image..." (100%)
4. See results with grade and annotated image

---

## 📂 File Organization

### Backend Files You Need:

1. **app.py** - NEW Flask API server
2. **grade_proof.py** - Your existing grading script
3. **find_text_lines.py** - Your existing text detection
4. **__init__.py** - Your existing init file
5. **requirements.txt** - NEW dependencies file
6. **.env** - Your API key configuration

### Frontend Files:

1. **App.jsx** - NEW React component with blue/yellow colors

---

## 🐛 Troubleshooting

### Problem: "CORS error" in browser console

**Solution:** Make sure flask-cors is installed:
```bash
pip install flask-cors
```

### Problem: "Connection refused"

**Solution:** Make sure backend is running:
```bash
cd backend
python app.py
```

### Problem: "ANTHROPIC_API_KEY not set"

**Solution:** Create `.env` file in backend folder with your API key

### Problem: "No module named 'cv2'"

**Solution:** Install OpenCV:
```bash
pip install opencv-python
```

### Problem: Colors not showing in frontend

**Solution:** The new App.jsx uses inline styles, so colors should work. Make sure you replaced the entire file.

### Problem: "Font not found" warning

**Solution:** This won't break functionality, but for better annotations:
- Linux: `sudo apt-get install fonts-dejavu-core`
- Mac: Font should already be available
- Windows: Download DejaVuSans.ttf and place in backend folder

---

## 🎯 API Endpoints Reference

### POST /api/grade
Upload a proof image for grading

**Request:**
- Content-Type: multipart/form-data
- Body: file (image file)

**Response:**
```json
{
  "jobId": "550e8400-e29b-41d4-a716-446655440000"
}
```

### GET /api/grade/:jobId
Check processing status

**Response:**
```json
{
  "status": "processing",
  "progress": 40,
  "message": "Grading proof..."
}
```

### GET /api/results/:jobId
Get final results (only when status = "done")

**Response:**
```json
{
  "total_grade": "B+",
  "sections": [
    {
      "number": 3,
      "error": "Missing justification for step"
    }
  ],
  "pdfAnnotatedUrl": "/outputs/123_annotated.jpg"
}
```

---

## 🚀 Production Deployment Notes

For production deployment, you should:

1. **Use a production WSGI server** (not Flask's dev server):
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 app:app
   ```

2. **Use a proper database** (not in-memory `jobs` dict):
   - Redis for job queue
   - PostgreSQL for storing results

3. **Add authentication/authorization**

4. **Set up file storage**:
   - AWS S3 or similar for uploaded/annotated images
   - Don't store on local filesystem

5. **Environment variables**:
   - Use proper secrets management
   - Don't commit .env file

6. **Update CORS settings**:
   ```python
   CORS(app, origins=["https://your-frontend-domain.com"])
   ```

---

## 📞 Support

If you encounter issues:

1. Check both terminal outputs (backend and frontend)
2. Check browser console for errors
3. Verify `.env` file has correct API key
4. Make sure all dependencies are installed
5. Try the `/api/test` endpoint to verify backend is running

---

## ✅ Quick Start Checklist

- [ ] Install Python dependencies (`pip install -r requirements.txt`)
- [ ] Create `.env` file with ANTHROPIC_API_KEY
- [ ] Start backend (`python app.py`)
- [ ] Test backend (`curl http://localhost:5000/api/test`)
- [ ] Install Node dependencies (`npm install framer-motion`)
- [ ] Replace App.jsx with new colorful version
- [ ] Start frontend (`npm start`)
- [ ] Upload a test proof image
- [ ] Verify you see colorful blue/yellow interface
- [ ] Check that grading works end-to-end

---

**🎉 That's it! Your proof grading system should now be fully connected and working!**
