"""
Test script to verify the backend API is working correctly
Run this after starting the Flask server to test all endpoints
"""

import requests
import time
import sys

BASE_URL = "http://localhost:5000"

def test_connection():
    """Test if backend is running"""
    print("🔍 Testing backend connection...")
    try:
        response = requests.get(f"{BASE_URL}/api/test")
        if response.status_code == 200:
            print("✅ Backend is running!")
            print(f"   Response: {response.json()}")
            return True
        else:
            print(f"❌ Backend returned status {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to backend. Make sure it's running on port 5000")
        print("   Run: python app.py")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_upload(image_path):
    """Test file upload and processing"""
    print(f"\n📤 Testing file upload with: {image_path}")
    
    try:
        # Check if file exists
        with open(image_path, 'rb') as f:
            files = {'file': f}
            
            print("   Uploading file...")
            response = requests.post(f"{BASE_URL}/api/grade", files=files)
            
            if response.status_code != 200:
                print(f"❌ Upload failed with status {response.status_code}")
                print(f"   Response: {response.text}")
                return None
            
            data = response.json()
            job_id = data.get('jobId')
            print(f"✅ Upload successful! Job ID: {job_id}")
            return job_id
            
    except FileNotFoundError:
        print(f"❌ File not found: {image_path}")
        return None
    except Exception as e:
        print(f"❌ Upload error: {e}")
        return None

def test_status(job_id):
    """Test status checking"""
    print(f"\n📊 Monitoring job status...")
    
    max_attempts = 60  # 60 seconds max
    attempt = 0
    
    while attempt < max_attempts:
        try:
            response = requests.get(f"{BASE_URL}/api/grade/{job_id}")
            
            if response.status_code != 200:
                print(f"❌ Status check failed: {response.status_code}")
                return False
            
            data = response.json()
            status = data.get('status')
            progress = data.get('progress', 0)
            message = data.get('message', '')
            
            print(f"   [{progress}%] {status}: {message}")
            
            if status == 'done':
                print("✅ Processing complete!")
                return True
            elif status == 'failed':
                print("❌ Processing failed")
                return False
            
            time.sleep(1)
            attempt += 1
            
        except Exception as e:
            print(f"❌ Status check error: {e}")
            return False
    
    print("❌ Timeout: Processing took too long")
    return False

def test_results(job_id):
    """Test results retrieval"""
    print(f"\n📋 Retrieving results...")
    
    try:
        response = requests.get(f"{BASE_URL}/api/results/{job_id}")
        
        if response.status_code != 200:
            print(f"❌ Results fetch failed: {response.status_code}")
            return False
        
        data = response.json()
        print("✅ Results retrieved successfully!")
        print(f"\n   Grade: {data.get('total_grade')}")
        print(f"   Errors found: {len(data.get('sections', []))}")
        print(f"   Annotated image: {data.get('pdfAnnotatedUrl')}")
        
        # Print errors
        errors = data.get('sections', [])
        if errors:
            print("\n   Errors:")
            for error in errors:
                print(f"      Line {error['number']}: {error['error']}")
        else:
            print("\n   No errors found!")
        
        return True
        
    except Exception as e:
        print(f"❌ Results error: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("🧪 Backend API Test Suite")
    print("=" * 60)
    
    # Test 1: Connection
    if not test_connection():
        print("\n❌ Backend is not running. Please start it first:")
        print("   cd backend")
        print("   python app.py")
        sys.exit(1)
    
    # Test 2: Check for test image
    print("\n" + "=" * 60)
    print("📸 Image Upload Test")
    print("=" * 60)
    
    # Try to find a test image
    test_images = [
        'test_proof.jpg',
        'test_proof.png',
        'proof.jpg',
        'proof.png'
    ]
    
    test_image = None
    for img in test_images:
        try:
            with open(img, 'rb'):
                test_image = img
                break
        except FileNotFoundError:
            continue
    
    if not test_image:
        print("\n⚠️  No test image found. To test upload:")
        print("   1. Place a proof image in the current directory")
        print("   2. Name it 'test_proof.jpg' or 'test_proof.png'")
        print("   3. Run this script again")
        print("\n✅ Connection test passed! Backend is ready.")
        return
    
    # Test 3: Upload
    job_id = test_upload(test_image)
    if not job_id:
        sys.exit(1)
    
    # Test 4: Status monitoring
    if not test_status(job_id):
        sys.exit(1)
    
    # Test 5: Get results
    if not test_results(job_id):
        sys.exit(1)
    
    print("\n" + "=" * 60)
    print("🎉 All tests passed! Backend is working correctly!")
    print("=" * 60)
    print("\nYou can now:")
    print("  1. Start your React frontend: npm start")
    print("  2. Open http://localhost:3000")
    print("  3. Upload a proof image and see it graded!")

if __name__ == "__main__":
    main()
