# 🚀 Pushing Your Project to GitHub - Step by Step

## ⚠️ IMPORTANT: Security Checklist (Do This FIRST!)

Before pushing to GitHub, make sure you:

- [ ] Created `.gitignore` file (prevents committing secrets)
- [ ] **REMOVED** any `.env` files from your project (or at least from git tracking)
- [ ] Created `.env.example` instead (template without real keys)
- [ ] **DOUBLE-CHECKED** no API keys are in any committed files
- [ ] Removed any uploaded images or test data

---

## 📋 Step-by-Step Guide

### Step 1: Prepare Your Local Repository

```bash
# Navigate to your project root
cd /path/to/your/project

# Initialize git (if not already done)
git init

# Copy the .gitignore file to your project root
# Make sure it's named exactly ".gitignore"
```

### Step 2: Security Check - Remove Sensitive Files

**CRITICAL: Check for API keys before committing!**

```bash
# Search for potential API keys in your code
grep -r "sk-ant-" .
grep -r "ANTHROPIC_API_KEY" .

# If you find any hardcoded keys, REMOVE THEM!
```

**If you already have a .env file:**

```bash
# Make sure .env is NOT tracked
git rm --cached .env 2>/dev/null || true

# Verify .gitignore includes .env
cat .gitignore | grep ".env"
```

### Step 3: Create .env.example (Safe Template)

```bash
# Copy your .env to .env.example
cp .env .env.example

# Edit .env.example and replace real values with placeholders
# Example:
# ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

### Step 4: Organize Your Files

Your structure should look like:

```
your-project/
├── backend/
│   ├── app.py
│   ├── grade_proof.py
│   ├── find_text_lines.py
│   ├── __init__.py
│   ├── requirements.txt
│   ├── test_backend.py
│   └── .env.example
├── frontend/
│   ├── src/
│   │   └── App.jsx
│   ├── package.json
│   └── ...
├── .gitignore          ← At project root!
├── .env.example        ← Safe template
├── README.md           ← GitHub README
├── SETUP_INSTRUCTIONS.md
└── ARCHITECTURE.md
```

### Step 5: Stage Your Files

```bash
# Add all files to staging
git add .

# Check what will be committed
git status

# Make sure you DON'T see:
# - .env (actual environment file)
# - uploads/ folder
# - outputs/ folder
# - Any .jpg, .png files
# - __pycache__/ folders
```

### Step 6: First Commit

```bash
# Make your first commit
git commit -m "Initial commit: AI-powered proof grading system"
```

### Step 7: Create GitHub Repository

1. Go to [GitHub](https://github.com)
2. Click the "+" icon in top right
3. Select "New repository"
4. Fill in:
   - **Repository name**: `proof-grader` (or your preferred name)
   - **Description**: "AI-powered mathematical proof grading using Claude AI"
   - **Visibility**: Choose Public or Private
   - **DON'T** initialize with README (you already have one)
5. Click "Create repository"

### Step 8: Connect to GitHub

GitHub will show you commands. Use these:

```bash
# Add GitHub as remote
git remote add origin https://github.com/YOUR_USERNAME/proof-grader.git

# Or if using SSH:
git remote add origin git@github.com:YOUR_USERNAME/proof-grader.git

# Verify remote was added
git remote -v
```

### Step 9: Push to GitHub

```bash
# Push your code
git push -u origin main

# Or if your branch is named "master":
git push -u origin master
```

### Step 10: Verify on GitHub

1. Go to your repository URL: `https://github.com/YOUR_USERNAME/proof-grader`
2. Check that:
   - ✅ README.md is displaying
   - ✅ .gitignore is present
   - ✅ .env.example is present
   - ❌ NO .env file (should be ignored)
   - ❌ NO uploaded images
   - ❌ NO API keys visible anywhere

---

## 🔒 Security Verification Checklist

After pushing, verify:

```bash
# Clone your repo in a different folder to test
cd /tmp
git clone https://github.com/YOUR_USERNAME/proof-grader.git
cd proof-grader

# Search for API keys (should find NONE!)
grep -r "sk-ant-" .
grep -r "ANTHROPIC_API_KEY" . | grep -v ".env.example"

# If you find any real keys, immediately:
# 1. Delete them from your code
# 2. Revoke the API key at Anthropic console
# 3. Generate a new key
# 4. Force push to overwrite history
```

---

## 🆘 Emergency: I Committed My API Key!

If you accidentally committed your API key:

### 1. **Immediately Revoke the Key**
- Go to https://console.anthropic.com/
- Delete the exposed API key
- Generate a new one

### 2. **Remove from Git History**

```bash
# Install BFG Repo Cleaner (easier than git-filter-branch)
# Download from: https://rtyley.github.io/bfg-repo-cleaner/

# Remove the sensitive file from history
java -jar bfg.jar --delete-files .env

# Clean up
git reflog expire --expire=now --all
git gc --prune=now --aggressive

# Force push (overwrites GitHub history)
git push --force
```

### 3. **Better Method: Use Git Filter-Repo**

```bash
# Install git-filter-repo
pip install git-filter-repo

# Remove .env from entire history
git filter-repo --path .env --invert-paths

# Force push
git push --force
```

---

## 📝 Add Repository Secrets (for CI/CD later)

If you want to set up GitHub Actions:

1. Go to your repo on GitHub
2. Click **Settings**
3. Click **Secrets and variables** → **Actions**
4. Click **New repository secret**
5. Add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: Your actual API key

This keeps keys secure for automated testing!

---

## 🎨 Optional: Add Repository Badges

Add to your README.md:

```markdown
![Python](https://img.shields.io/badge/python-3.8+-blue.svg)
![React](https://img.shields.io/badge/react-18+-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Stars](https://img.shields.io/github/stars/YOUR_USERNAME/proof-grader)
```

---

## 📄 Optional: Add a License

```bash
# Create LICENSE file (MIT License example)
cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2025 Your Name

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF

# Add and commit
git add LICENSE
git commit -m "Add MIT License"
git push
```

---

## 🔄 Future Updates

When making changes:

```bash
# Make your changes to files

# Stage changes
git add .

# Commit with descriptive message
git commit -m "Add feature: improved error detection"

# Push to GitHub
git push
```

---

## 🌟 Make Your Repo Stand Out

1. **Add Screenshots** - Put example images in a `docs/images/` folder
2. **Create Demo GIF** - Show the app in action
3. **Write Good Commit Messages** - Be descriptive
4. **Add Topics/Tags** - On GitHub, add tags like: `ai`, `machine-learning`, `education`, `opencv`, `flask`, `react`
5. **Star and Watch** - Help others discover your project

---

## ✅ Final Checklist

Before sharing your repository:

- [ ] .gitignore is in place
- [ ] No .env file committed
- [ ] .env.example is provided
- [ ] README.md is clear and helpful
- [ ] All setup instructions are documented
- [ ] Test that someone else can clone and run it
- [ ] API keys are secure
- [ ] License is added (optional but recommended)
- [ ] Repository description is filled in
- [ ] Topics/tags are added

---

## 🎉 You're Done!

Your project is now on GitHub! Share it:

```
https://github.com/YOUR_USERNAME/proof-grader
```

**Remember:** Never commit sensitive data. If unsure, ask before pushing!
