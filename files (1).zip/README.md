# 🎯 Quick Reference - Proof Grading System

## 📦 Files You've Received

### Backend Files
1. **app.py** - Flask API server that connects everything
2. **requirements.txt** - Python dependencies  
3. **test_backend.py** - Test script to verify backend works

### Frontend Files
4. **App.jsx** - React component with blue/yellow colors

### Documentation
5. **SETUP_INSTRUCTIONS.md** - Complete step-by-step setup guide
6. **ARCHITECTURE.md** - Visual diagrams of how it all works
7. **README.md** - This file!

---

## ⚡ Ultra-Quick Start (5 minutes)

### Backend Setup
```bash
# 1. Put these files in your backend folder:
#    - app.py
#    - grade_proof.py (your existing file)
#    - find_text_lines.py (your existing file)
#    - __init__.py (your existing file)
#    - requirements.txt

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create .env file with your API key
echo "ANTHROPIC_API_KEY=your_key_here" > .env

# 4. Start server
python app.py
```

### Frontend Setup
```bash
# 1. Replace src/App.jsx with the new colorful version

# 2. Install dependency
npm install framer-motion

# 3. Start frontend
npm start
```

### Test It
```bash
# In browser, go to http://localhost:3000
# You should see blue and yellow colorful UI
# Upload a proof image and watch it get graded!
```

---

## 🔧 What Each File Does

### app.py (Flask Backend)
- Creates REST API endpoints
- Handles file uploads
- Manages background job processing
- Calls your existing Python scripts
- Serves annotated images

### App.jsx (React Frontend)  
- Beautiful blue & yellow UI
- Drag & drop file upload
- Real-time progress tracking
- Displays grades and errors
- Shows annotated images

### grade_proof.py (Your Existing Code)
- Sends images to Claude AI
- Gets grading feedback
- Annotates images with error bubbles

### find_text_lines.py (Your Existing Code)
- Detects text lines with OpenCV
- Draws boxes and numbers on lines
- Returns layout data

---

## 🌐 API Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/test` | Check if backend is running |
| POST | `/api/grade` | Upload proof image |
| GET | `/api/grade/:id` | Check processing status |
| GET | `/api/results/:id` | Get grading results |
| GET | `/outputs/:filename` | Get annotated images |

---

## 🎨 Color Scheme

The frontend uses a pretty blue and yellow theme:

- **Blue**: `#4A9FD8` (primary), `#2E6FA8` (dark), `#6BB3E0` (light)
- **Yellow**: `#FFD966` (primary), `#FFC533` (dark)  
- **Backgrounds**: Light blue (`#E8F4FD`) and light yellow (`#FFF9E6`)

All elements are highly visible with solid colors and borders!

---

## 🐛 Common Issues & Solutions

### "Cannot connect to backend"
```bash
# Make sure backend is running:
python app.py

# Should see: "Server running on http://localhost:5000"
```

### "CORS error"
```bash
# Install flask-cors:
pip install flask-cors
```

### "No module named 'anthropic'"
```bash
# Install all dependencies:
pip install -r requirements.txt
```

### "Colors not showing"
- Make sure you replaced the ENTIRE App.jsx file
- The new version uses inline styles that always work

### "API key error"
```bash
# Create .env file in backend folder:
echo "ANTHROPIC_API_KEY=your_actual_key" > .env
```

---

## 📊 Processing Flow

```
1. User uploads image
   ↓
2. Backend saves to uploads/
   ↓
3. OpenCV detects text lines
   ↓
4. Claude AI grades the proof
   ↓
5. Image annotated with errors
   ↓
6. Results sent to frontend
   ↓
7. User sees grade + annotated image
```

---

## 🧪 Testing

### Test Backend Only
```bash
python test_backend.py
```

### Test API Manually
```bash
# Test connection
curl http://localhost:5000/api/test

# Should return:
# {"message": "Backend connected!", "status": "ok"}
```

### Test Full System
1. Start backend: `python app.py`
2. Start frontend: `npm start`
3. Open http://localhost:3000
4. Upload a proof image
5. Watch it process
6. See results!

---

## 📁 Folder Structure

```
your-project/
├── backend/
│   ├── app.py              ← NEW Flask server
│   ├── grade_proof.py      ← Your existing
│   ├── find_text_lines.py  ← Your existing
│   ├── __init__.py         ← Your existing
│   ├── requirements.txt    ← NEW dependencies
│   ├── test_backend.py     ← NEW test script
│   ├── .env                ← Create this (API key)
│   ├── uploads/            ← Auto-created
│   └── outputs/            ← Auto-created
│
└── frontend/
    ├── src/
    │   └── App.jsx         ← NEW colorful version
    ├── package.json
    └── ...
```

---

## 🚀 Production Checklist

Before deploying to production:

- [ ] Use gunicorn instead of Flask dev server
- [ ] Set up proper database (not in-memory jobs dict)
- [ ] Configure CORS for your domain only
- [ ] Use environment variables for secrets
- [ ] Set up file storage (S3, etc.)
- [ ] Add authentication/authorization
- [ ] Set up monitoring and logging
- [ ] Add rate limiting
- [ ] Use HTTPS

---

## 💡 Pro Tips

1. **Keep both servers running** - Backend (port 5000) and Frontend (port 3000)

2. **Check browser console** - Errors show up here (F12 in most browsers)

3. **Check terminal output** - Both backend and frontend logs are helpful

4. **Test backend first** - Run `python test_backend.py` before testing frontend

5. **Font files** - DejaVuSans.ttf makes annotations look better (optional)

---

## 📚 Additional Resources

- **Flask Documentation**: https://flask.palletsprojects.com/
- **React Documentation**: https://react.dev/
- **Anthropic API Docs**: https://docs.anthropic.com/
- **Framer Motion**: https://www.framer.com/motion/

---

## ✅ Success Indicators

You'll know it's working when:

✅ Backend shows "Server running on http://localhost:5000"  
✅ Frontend opens at http://localhost:3000  
✅ You see blue and yellow colorful interface  
✅ No CORS errors in browser console  
✅ Upload works and shows progress  
✅ Results display with grade and annotated image  

---

## 🆘 Need Help?

1. Read **SETUP_INSTRUCTIONS.md** for detailed setup
2. Check **ARCHITECTURE.md** to understand how it works
3. Run `python test_backend.py` to diagnose backend issues
4. Check browser console (F12) for frontend errors
5. Verify `.env` file has correct API key

---

**Made with ❤️ using Flask, React, OpenCV, and Claude AI**

*Last updated: 2025*
