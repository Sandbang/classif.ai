"""
Flask Backend API for Proof Grading System
This connects your React frontend to the Python grading scripts
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import json
import uuid
import threading
import time
from dotenv import load_dotenv

# Import your grading functions
import grade_proof
import find_text_lines

load_dotenv()

app = Flask(__name__)
CORS(app)  # Enable CORS for React frontend

# Configuration
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

# Create necessary folders
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# Job tracking (in-memory storage - use Redis/database for production)
jobs = {}

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_proof(job_id, image_path):
    """
    Background task to process the proof image
    Updates the job status as it progresses
    """
    try:
        # Update status: Starting
        jobs[job_id]['status'] = 'processing'
        jobs[job_id]['progress'] = 10
        jobs[job_id]['message'] = 'Detecting text lines...'
        
        # Step 1: Find text lines (20-40% progress)
        print(f"[Job {job_id}] Running text line detection...")
        boxed_image_array, layout_data_list = find_text_lines.find_text_lines(image_path)
        
        if boxed_image_array is None or layout_data_list is None:
            jobs[job_id]['status'] = 'failed'
            jobs[job_id]['message'] = 'Failed to detect text lines in image'
            return
        
        jobs[job_id]['progress'] = 40
        jobs[job_id]['message'] = 'Text detection complete. Grading proof...'
        
        # Step 2: Grade the proof with Claude (40-70% progress)
        print(f"[Job {job_id}] Sending to Claude for grading...")
        grading_result = grade_proof.grade_proof_image(image_array=boxed_image_array)
        
        if not grading_result:
            jobs[job_id]['status'] = 'failed'
            jobs[job_id]['message'] = 'Failed to get grading from AI'
            return
        
        jobs[job_id]['progress'] = 70
        jobs[job_id]['message'] = 'Creating annotated image...'
        
        # Step 3: Create annotated image (70-100% progress)
        errors = grading_result.get('errors', [])
        
        if errors:
            # Prepare layout map
            layout_map = {item['number']: item['box'] for item in layout_data_list}
            
            # Create annotated image
            print(f"[Job {job_id}] Annotating image with errors...")
            grade_proof.annotate_image(
                image_array=boxed_image_array,
                layout_map=layout_map,
                errors_list=errors,
                original_image_path=image_path
            )
            
            # Get the annotated image path
            base = os.path.basename(image_path)
            name, ext = os.path.splitext(base)
            annotated_path = f"annotated_{name}.jpg"
            
            # Move to outputs folder
            if os.path.exists(annotated_path):
                output_path = os.path.join(OUTPUT_FOLDER, f"{job_id}_annotated.jpg")
                os.rename(annotated_path, output_path)
                jobs[job_id]['annotated_image'] = f"/outputs/{job_id}_annotated.jpg"
        else:
            # No errors - just use the original boxed image
            output_path = os.path.join(OUTPUT_FOLDER, f"{job_id}_result.jpg")
            import cv2
            cv2.imwrite(output_path, boxed_image_array)
            jobs[job_id]['annotated_image'] = f"/outputs/{job_id}_result.jpg"
        
        # Step 4: Store results
        jobs[job_id]['progress'] = 100
        jobs[job_id]['message'] = 'Complete!'
        jobs[job_id]['status'] = 'done'
        jobs[job_id]['results'] = {
            'total_grade': grading_result.get('total_grade', 'N/A'),
            'sections': errors,
            'pdfAnnotatedUrl': jobs[job_id]['annotated_image']
        }
        
        print(f"[Job {job_id}] Processing complete!")
        
    except Exception as e:
        print(f"[Job {job_id}] Error: {str(e)}")
        jobs[job_id]['status'] = 'failed'
        jobs[job_id]['message'] = f'Processing error: {str(e)}'


# ===== API ENDPOINTS =====

@app.route('/api/test', methods=['GET'])
def test_connection():
    """Test endpoint to verify backend is running"""
    return jsonify({
        'message': 'Backend connected!',
        'status': 'ok'
    })

@app.route('/api/grade', methods=['POST'])
def upload_file():
    """
    Upload endpoint - receives image file and starts processing
    Returns a job ID for tracking progress
    """
    # Check if file is in request
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    # Check if file is selected
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Check file type
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type. Please upload PNG, JPG, JPEG, or GIF'}), 400
    
    try:
        # Generate unique job ID
        job_id = str(uuid.uuid4())
        
        # Save uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{job_id}_{filename}")
        file.save(filepath)
        
        # Initialize job tracking
        jobs[job_id] = {
            'status': 'processing',
            'progress': 0,
            'message': 'Starting...',
            'filename': filename,
            'filepath': filepath
        }
        
        # Start background processing
        thread = threading.Thread(target=process_proof, args=(job_id, filepath))
        thread.daemon = True
        thread.start()
        
        print(f"[Job {job_id}] Created - Processing {filename}")
        
        return jsonify({'jobId': job_id}), 200
        
    except Exception as e:
        print(f"Upload error: {str(e)}")
        return jsonify({'error': f'Upload failed: {str(e)}'}), 500

@app.route('/api/grade/<job_id>', methods=['GET'])
def get_job_status(job_id):
    """
    Status endpoint - returns current progress of a job
    """
    if job_id not in jobs:
        return jsonify({'error': 'Job not found'}), 404
    
    job = jobs[job_id]
    
    return jsonify({
        'status': job['status'],
        'progress': job['progress'],
        'message': job['message']
    })

@app.route('/api/results/<job_id>', methods=['GET'])
def get_results(job_id):
    """
    Results endpoint - returns final grading results
    """
    if job_id not in jobs:
        return jsonify({'error': 'Job not found'}), 404
    
    job = jobs[job_id]
    
    if job['status'] != 'done':
        return jsonify({'error': 'Job not complete yet'}), 400
    
    return jsonify(job['results'])

@app.route('/outputs/<path:filename>', methods=['GET'])
def serve_output(filename):
    """
    Serve annotated images from the outputs folder
    """
    return send_from_directory(app.config['OUTPUT_FOLDER'], filename)

# Clean up old jobs (optional - runs every hour)
def cleanup_old_jobs():
    """Remove jobs older than 1 hour"""
    while True:
        time.sleep(3600)  # Run every hour
        current_time = time.time()
        to_remove = []
        
        for job_id, job in jobs.items():
            # Remove jobs older than 1 hour
            if 'created_at' in job and current_time - job['created_at'] > 3600:
                to_remove.append(job_id)
                # Clean up files
                try:
                    if os.path.exists(job['filepath']):
                        os.remove(job['filepath'])
                except:
                    pass
        
        for job_id in to_remove:
            del jobs[job_id]
            print(f"Cleaned up old job: {job_id}")

# Start cleanup thread
cleanup_thread = threading.Thread(target=cleanup_old_jobs)
cleanup_thread.daemon = True
cleanup_thread.start()

if __name__ == '__main__':
    print("=" * 50)
    print("🚀 Proof Grading Backend Server Starting...")
    print("=" * 50)
    print("\n📋 Available Endpoints:")
    print("  GET  /api/test              - Test connection")
    print("  POST /api/grade             - Upload proof image")
    print("  GET  /api/grade/<job_id>    - Check processing status")
    print("  GET  /api/results/<job_id>  - Get grading results")
    print("  GET  /outputs/<filename>    - Get annotated images")
    print("\n" + "=" * 50)
    print("✅ Server running on http://localhost:5000")
    print("=" * 50 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
